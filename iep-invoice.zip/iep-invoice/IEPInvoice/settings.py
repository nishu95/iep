import os

import environ

from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
# BASE_DIR = Path(__file__).resolve().parent.parent

BASE_DIR = environ.Path(__file__) - 2

env = environ.Env()
env.read_env(BASE_DIR(".env"))
env.str("DATABASE_NAME")

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '6s6rc=7v3oqmvsnuz9@75i)3q4_v&hii=lkuenmgebrcljhz3&'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=["*"])


# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',
    'user',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'IEPInvoice.urls'

AUTH_USER_MODEL = "user.User"

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR('templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'IEPInvoice.wsgi.application'


# Database
# https://docs.djangoproject.com/en/2.2/ref/settings/#databases


DATABASES = {
    "default": {
        'ENGINE':'django.db.backends.mysql',
        'NAME': env.str('DATABASE_NAME'),
        'USER':env.str('DATABASE_USER'),
        'PASSWORD':env.str('DATABASE_PASSWORD'),
        'HOST':env.str('DATABASE_HOST', default='localhost'),
        'PORT':env.int('DATABASE_PORT', default='3306')
    }
}

# Password validation
# https://docs.djangoproject.com/en/2.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

BASE_URL = env.str('BASE_URL', 'http://127.0.0.1:8000/')

STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Internationalization
# https://docs.djangoproject.com/en/2.2/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/2.2/howto/static-files/

STATIC_URL = 'static/'

STATICFILES_DIRS = [
    os.path.join(BASE_DIR, "static"),
]

MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# Default primary key field type
# https://docs.djangoproject.com/en/4.2/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')  


# --------------Email Services------------------------------

# DEFAULT_FROM_EMAIL = env.str('DEFAULT_FROM_EMAIL')
# EMAIL_BACKEND = env.str('EMAIL_BACKEND')
# EMAIL_HOST = env.str('EMAIL_HOST')
# EMAIL_USE_TLS = env.str('EMAIL_USE_TLS')
# EMAIL_PORT = env.str('EMAIL_PORT')
# EMAIL_HOST_USER = env.str('EMAIL_HOST_USER') #sender's email-id
# EMAIL_HOST_PASSWORD = env.str('EMAIL_HOST_PASSWORD') #password associated with above email-id
# API_URL= env.str('API_URL')


# DEFAULT_FROM_EMAIL = 'IEP<teambeta.clavax@gmail.com>'
# EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
# EMAIL_HOST = 'smtp.gmail.com'
# EMAIL_USE_TLS = True
# EMAIL_PORT = 587
# EMAIL_HOST_USER = 'teambeta.clavax@gmail.com' #sender's email-id
# EMAIL_HOST_PASSWORD = 'burgendpeticwgrn' #password associated with above email-id



MONTHS = {
    1: 'January',
    2: 'Febraury',
    3: 'March',
    4: 'April',
    5: 'May',
    6: 'June',
    7: 'July',
    8: 'August',
    9: 'September',
    10: 'October',
    11: 'November',
    12: 'December'
}

