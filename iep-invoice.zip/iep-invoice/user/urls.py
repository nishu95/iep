from django.conf.urls import url
from django.http import HttpResponse
from django.urls import path
from user import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [

    path('',views.index,name='index'),
    path('signup/',views.signup,name='signup'),

    path('login/',views.login,name='login'),
    path('logout/',views.logout_view,name='logout'),
    path('forgot/',views.forgot,name='forgot'),

    path('add-staff/',views.signup,name='add_staff'),
    path('staff-list/',views.staffListView,name='staff_list'),
    path('reset-staff-password/<int:id>/', views.reset_staff_password, name='reset_staff_password'),
    path('delete-staff/<int:id>/',views.deleteStaff, name='delete_staff'),
    
    path('invoice-details1/',views.invoiceDetailsView,name='invoice_details'),
    path('invoice-basic-info/',views.invoiceBasicInfo,name='invoice_basic_info'),
    path('invoice-template-detail/<int:month>/<int:year>/',views.invoiceBasicDetail,name='invoice_template_detail'),
    path('invoice-template/',views.invoiceTemplate,name='invoice_template'),

    path('invoice-history/',views.invoiceHistory,name='invoice_history'),
    
    path('basic-info-save/',views.basic_info_save,name='basic_info_save'),
    path('invoice-details-save/',views.invoice_details_save,name='invoice_details_save'),
    path('deleteInvoiceData/<int:id>/',views.deleteInvoiceData,name='deleteInvoiceData'),
    path('getBasicDetails/<int:id>/',views.getBasicDetails,name='getBasicDetails'),
    
    
    path('download-invoice/<int:month>/<int:year>/',views.downloadInvoice,name='sendInvoiceMail'),
    path('send-invoice-mail/<int:month>/<int:year>/',views.sendInvoiceMail,name='sendInvoiceMail'),

    
    path('upload-excel/',views.upload_excel,name='upload-excel'),
    
    path('pdf/<str:invoice_date>/<int:group_id>/',views.pdf,name='pdf'),
    path('pdf_view/<str:invoice_date>/<int:group_id>/',views.pdf_view,name='pdf_view'),
    
    path('generate-pdf/<int:month>/<int:year>/',views.generate_pdf,name='generate_pdf'),


    path('invoice-details/',views.invoiceDetailsView,name='invoice_details'),
    path('add-student/',views.invoiceDetailsView,name='add_student'),

    path('single-student-save/',views.single_student_save,name='single_student_save'),
    path('student-service-detail/<int:id>/',views.studentServiceDetail,name='student_service_detail'),
    path('student-service-list/<int:group_id>/',views.studentServiceList,name='student-service-list'),
    path('student-group-list/',views.studentGroupList, name='student_group_list'),

    path('invoice-list/',views.invoiceList,name='invoice_list'),
    path('group-invoice-list/<str:inv_date>/<int:group_id>/',views.studentGroupInvoiceList,name='group-invoice-list'),
    path('update-invoice-date/<str:inv_date>/<int:group_id>/', views.update_invoice_date, name='update_invoice_date'),
    path('delete-invoice-group/<str:inv_date>/<int:group_id>/', views.delete_invoice_group, name='delete_invoice_group'),

    path('download-invoice-list/',views.downloadinvoiceList,name='download_invoice_list'),

    path('service-list/',views.serviceListView, name='service_list'),
    path('service/<int:id>/',views.serviceAdd, name='service'),
    path('service/',views.serviceAdd, name='service'),
    path('delete-service/<int:id>/',views.deleteService, name='delete_service'),


    path('group-list/',views.groupListView, name='group_list'),
    path('group/<int:id>/',views.groupAdd, name='group'),
    path('group/',views.groupAdd, name='group'),
    path('delete-group/<int:id>/',views.deleteGroup, name='delete_group'),

    path('send-mail/<int:pdf_id>/', views.sendMail, name='send_mail'),


    path('upload-pdf/', views.upload_pdf, name='upload_pdf'),
    path('delete-pdf/<int:id>/',views.deletePdf, name='delete_pdf'),
    path('display-pdf/<int:document_id>/', views.display_pdf, name='display_pdf'),

    # path('delete-pdf/', views.deletePdf, name='delete_pdf'),




    
    

    


    
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
