from django.core.mail import EmailMessage
from django.conf import settings


# --------------Send mail through GMAIL SMTP--------------------------

    
def send_invoice_email(receiver_email, pdf_invoice,inv_subject, desc):
    
        subject = f"Invoice: {inv_subject}"
        message = desc
        email_from = settings.EMAIL_HOST_USER
        
        recipient_list = [receiver_email]
        
        email = EmailMessage(subject, message, email_from, recipient_list)
        # Attach the PDF file
        email.attach_file(pdf_invoice.pdf_file.path)
        # Send the email
        email.send()




# --------------------Send Mail with Azure------------------------------

from azure.communication.email import EmailClient
import base64

def email_invoice(receiver_email, pdf_invoice, inv_subject, desc):
    # try:
        
        connection_string = "endpoint=https://iep-billing-email.unitedstates.communication.azure.com/;accesskey=8NdaWYWx1fNi2uDtQLGBIu1g6Qo6fb5RlCbim2zWmvlf9GqPjOpwJQQJ99AGACULyCp61IggAAAAAZCSVVRa"
        
        # print('connection_string', connection_string)
        client = EmailClient.from_connection_string(connection_string)

        # Read the PDF file and encode it in base64
        with open(pdf_invoice, "rb") as pdf_file:
            encoded_pdf = base64.b64encode(pdf_file.read()).decode('utf-8')

        message = {
            "senderAddress": "DoNotReply@stknedbilling.org",
            "recipients": {
                "to": [{"address": receiver_email}],
            },
            "content": {
                "subject": inv_subject,
                "plainText": desc,
            },
            "attachments": [
                {
                    "name": "invoice.pdf",
                    "contentType": "application/pdf",
                    "contentInBase64": encoded_pdf
                }
            ]
        }

        # print("connection_string", connection_string)
        # print("client", client)
        # print("message", message)

        poller = client.begin_send(message)
        result = poller.result()
        # print("result", result)

    # except Exception as ex:
    #     print(ex)






# ------------------------Plain Text------------------
    
from azure.communication.email import EmailClient
def test_mail():
    try:
        connection_string = "endpoint=https://iep-billing-email.unitedstates.communication.azure.com/;accesskey=8NdaWYWx1fNi2uDtQLGBIu1g6Qo6fb5RlCbim2zWmvlf9GqPjOpwJQQJ99AGACULyCp61IggAAAAAZCSVVRa"
        client = EmailClient.from_connection_string(connection_string)
 
        message = {
            "senderAddress": "DoNotReply@cdbb2a55-abe8-4cb3-800c-8f80c817b659.azurecomm.net",
            "recipients":  {
                "to": [{"address": "ravikumarg@clavax.com" }],
            },
            "content": {
                "subject": "Test Email",
                "plainText": "hello world",
            }
        }
 
        poller = client.begin_send(message)
        result = poller.result()
 
    except Exception as ex:
        print(ex)




        







