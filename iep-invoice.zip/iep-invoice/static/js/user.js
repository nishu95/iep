$(document).ready(function () {
    $(document).on("click", "#button-login", function(e) {
        $("#form-login").validate({
            ignore: ".ignore",
            rules: {
                email: {
                    required: true,
                    maxlength: 25
                },
                password: {
                    required: true,
                    maxlength: 255,
                },
            },
            messages: {
                'email': {
                    required: "Please enter email.",
                }, 
                'password': {
                    required: "Please Enter password.",
                },                            
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "option_id") {                  
                    error.appendTo("#errorToShow");
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                var email = $('#email').val();               
                var password = $('#password').val();
                console.log("email")
                var token = $('input[name="csrfmiddlewaretoken"]').val();                
                let csrftoken = '{{ csrf_token }}'
                $.ajax({
                    url: "/login/",
                    type: "POST",
                    headers: {'X-CSRFToken': token},
                    data: {'email': email, 'password': password},
                    cache: false,
                    success: function(data) {
                        if (data.error == 1) {
                            
                            $().msgpopup({
                                text: data.msg,
                                success: false, 
                                time: 2000, 
                                x: true, 
                            });
                        } else {
                            if (data.is_superuser) {
                                window.location.href = '/invoice-details'; 
                            } else if (data.is_staff) {
                                window.location.href = '/invoice-basic-info';
                            } else {
                                window.location.href = '/invoice-details';
                            }
                        }
                    },
                    complete: function(jqXhr) {
                        $(".loaderDiv").hide();
                    }
                }); 
            }
        });
            
        
    });

    $(document).on("click", "#basic-info-button", function(e) {
        $("#basic-info-form").validate({
            ignore: ".ignore",
            rules: {
                from_name: {
                    required: true,
                    maxlength: 25
                },
                to_name: {
                    required: true,
                    maxlength: 25
                },

                from_address: {
                    required: true,
                    maxlength: 200
                },

                to_address: {
                    required: true,
                    maxlength: 200
                },
                approved_by_detail: {
                    required: true,
                    maxlength: 30
                },

                prepared_by_detail: {
                    required: true,
                    maxlength: 30
                },
                
            },
            messages: {
                'from_name': {
                    required: "Please enter from name.",
                }, 
                
                'to_name': {
                    required: "Please enter to name.",
                },
                
                'from_address': {
                    required: "Please enter from address.",
                }, 
                
                'to_address': {
                    required: "Please enter to address.",
                },
                
                'approved_by_detail': {
                    required: "Please enter approved by detail",
                }, 
                
                'prepared_by_detail': {
                    required: "Please enter prepared by detail",
                },  
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "option_id") {                  
                    error.appendTo("#errorToShow");
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });   
        
    });

    // $(document).on("change", "#selectmonth", function(e) {
    //     alert('mm');
    // });

    // $("#selectmonth").change(function(){
    //     var selectmonth = $('#selectmonth').val();
    //     $.ajax({
    //         url: "/getBasicDetails/" + selectmonth + "/",
    //         type: "GET",
    //         cache: false,
    //         success: function(result) {
    //             alert(result.message)
    //             console.log("data");
    //             alert("doneee")
                
    //             alert(data);
    //             // window.location.href = '/';
    //         },
    //         complete:function(jqXhr){
    //             $(".loaderDiv").hide();
    //             // redirectLogin(jqXhr)
    //         }
    //     });
    // });
    $("#selectmonth").change(function(){
    var selectmonth = $('#selectmonth').val();
    $.ajax({
            url: "/getBasicDetails/" + selectmonth + "/",
            type: "GET",
            cache: false,
            success: function(result) {
                // alert(result.message);
                // console.log(result.data);
                // alert("done");
                // console.log(result.data);
                if (result.success==true){
                    $('#from_name').val(result.data.from_name);
                    $('#to_name').val(result.data.to_name);
                    $('#from_address').val(result.data.from_address);
                    $('#to_address').val(result.data.to_address);
                    $('#invoice_date').val(result.data.invoice_date);
                    $('#invoice_period_from').val(result.data.invoice_period_from);
                    $('#invoice_period_to').val(result.data.invoice_period_to);
                    $('#from_address').val(result.data.from_address);
                    $('#logo').html('<i><img src="/media/'+result.data.logo+'" alt="icon"></i>')
                    $('#prepared_by').html('<i><img src="/media/'+result.data.logo+'" alt="icon"></i>')
                    $('#approved_by').html('<i><img src="/media/'+result.data.approved_by+'" alt="icon"></i>')
                    $('#approved_by_detail').val(result.data.approved_by_detail);
                    $('#prepared_by_detail').val(result.data.prepared_by_detail);
                    // $("#skip").style.display="block";
                    $("#skip").css("display", "block");
                }
                else{
                    $('#from_name').val('');
                    $('#to_name').val('');
                    $('#from_address').val('');
                    $('#to_address').val('');
                    $('#invoice_date').val('');
                    $('#invoice_period_from').val('');
                    $('#invoice_period_to').val('');
                    $('#from_address').val('');
                    $('#logo').html('<i><img src="/static/images/file-icon.svg" alt="icon"></i>')
                    $('#prepared_by').html('<i><img src="/static/images/file-icon.svg" alt="icon"></i>')
                    $('#approved_by').html('<i><img src="/static/images/file-icon.svg" alt="icon"></i>')
                    $('#approved_by_detail').val('');
                    $('#prepared_by_detail').val('');
                    $("#skip").css("display", "none");
                }
                
                // Handle data here...
            },
            complete: function(jqXhr){
                $(".loaderDiv").hide();
                // Handle completion here...
            }
        });
    });

    $(document).on("click", "#add_student_btn", function(e) {
        var stud = $('#user').val();
        var to_pay = $('#user').find('option:selected').attr("data-studname");
        if(stud == ""){
            alert("Please Select Student");
            return false;
        }
        $('#student_name_tab').html(to_pay);
        $('#student_tab').show();
    });

    $(document).on("click", "#stud_toggle_show", function(e) {
        $('#student_tab').css('display','none');
    });

    $(document).on("click", ".invoice_delete", function(e) {
        var id = $(this).attr("data-invoiceID");
        var confirmation = confirm("are you sure you want to remove the Student Detail?");
        // alert(id);
        if (confirmation){
            $.ajax({
                url: "/deleteInvoiceData/" + id + "/",
                type: "GET",
                // headers:{'X-CSRFToken':token},
                // data:{
                //     'InvID': InvID  
                // },
                cache: false,
                success: function(data) {
                    if(data.error == "1"){
                        $().msgpopup({
                            text: data.msg,
                            success: false, // false
                            time: 2000, // or false
                            x: true, // or false
                        });
                    } else {
                        alert("Removed Successfully")
                        window.location.href = '/invoice-details';
                    }
                    
                    // alert(data);
                    // window.location.href = '/';
                },
                complete:function(jqXhr){
                    $(".loaderDiv").hide();
                    // redirectLogin(jqXhr)
                }
            });
        } 
    });

    /* Download Student Invocie */
    $(document).on("click", ".invoice_download", function(e) {
        var month = $(this).attr("data-dmonth");
        var year = $(this).attr("data-dyear");
        alert(year);
        alert(month);
        var confirmation = confirm("are you sure you want to remove the Student Detail?");
        $.ajax({
            url: "/download_invoice/" + month + "/"+ year + "/",
            type: "GET",
            // headers:{'X-CSRFToken':token},
            // data:{
            //     'InvID': InvID  
            // },
            cache: false,
            success: function(data) {
                if(data.error == "1"){
                    $().msgpopup({
                        text: data.msg,
                        success: false, // false
                        time: 2000, // or false
                        x: true, // or false
                    });
                } else {
                    window.location.href = '/invoice-details';
                }
                
                // alert(data);
                // window.location.href = '/';
            },
            complete:function(jqXhr){
                $(".loaderDiv").hide();
                // redirectLogin(jqXhr)
            }
        }); 
    });

    /* Send Mail Invoice details */
    $(document).on("click", ".mail_invoice", function(e) {
        var month = $(this).attr("data-smonth");
        var year = $(this).attr("data-syear");
        // alert(id);
        $.ajax({
            url: "/send-invoice-mail/" + month + "/"+ year + "/",
            type: "GET",
            // headers:{'X-CSRFToken':token},
            // data:{
            //     'InvID': InvID  
            // },
            cache: false,
            success: function(data) {
                if(data.error == "1"){
                    $().msgpopup({
                        text: data.msg,
                        success: false, // false
                        time: 5000, // or false
                        x: true, // or false
                    });
                } else {
                    // alert(data.msg)
                    $().msgpopup({
                        text: data.msg,
                        success: true, // false
                        time: 5000, // or false
                        x: true, // or false
                    });
                    // window.location.href = '/invoice-details';
                }
                
                // alert(data);
                // window.location.href = '/';
            },
            complete:function(jqXhr){
                $(".loaderDiv").hide();
                // redirectLogin(jqXhr)
            }
        }); 
    });

    $('.subvalcls').on('keyup', function (event) {
        var attendance_subtotal = $('#attendance_subtotal').val();
        var trt_subtotal = $('#trt_subtotal').val();
        var aide_subtotal = $('#aide_subtotal').val();
        var aid_subtotal = $('#aid_subtotal').val();
        var lang_speech_subtotal = $('#lang_speech_subtotal').val();
        var behavior_subtotal = $('#behavior_subtotal').val();
        var occupational_subtotal = $('#occupational_subtotal').val();
        var ic_subtotal = $('#ic_subtotal').val();
        var ca_subtotal = $('#ca_subtotal').val();
        var ot_subtotal = $('#ot_subtotal').val();

        if(attendance_subtotal != '' && attendance_subtotal != undefined & 
        trt_subtotal != '' && trt_subtotal != undefined &
        aide_subtotal != '' && aide_subtotal != undefined &
        aid_subtotal != '' && aid_subtotal != undefined &
        lang_speech_subtotal != '' && lang_speech_subtotal != undefined &
        behavior_subtotal != '' && behavior_subtotal != undefined &
        occupational_subtotal != '' && occupational_subtotal != undefined &
        ic_subtotal != '' && ic_subtotal != undefined & 
        ca_subtotal != '' && ca_subtotal != undefined &
        ot_subtotal != '' && ot_subtotal != undefined ){
            var f_total = Number(attendance_subtotal) + Number(trt_subtotal) + Number(aide_subtotal) + Number(aid_subtotal) + Number(lang_speech_subtotal) + 
            Number(behavior_subtotal) + Number(occupational_subtotal) + Number(ca_subtotal) + Number(ot_subtotal)

            // alert(f_total);
            $("#total").val(f_total);

            obj2 = new Intl.NumberFormat('en-US');  
            output2 = obj2.format(f_total);  

            $('#finalTotal').html(output2);
            
        }
        
        
    });
    

    $(document).on("click", "#invoice-details-button", function(e) {
        $("#invoice-details-form").validate({
            ignore: ".ignore",
            rules: {
                user: {
                    required: true,
                    maxlength: 25
                },
                attendance: {
                    required: true,
                    maxlength: 25
                },
                attendance_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                attendance_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                trt: {
                    required: true,
                    maxlength: 25
                },
                trt_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                trt_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                aide: {
                    required: true,
                    maxlength: 25
                },
                aide_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                aide_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },

                aid: {
                    required: true,
                    maxlength: 25
                    
                },
                aid_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                aid_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },

                lang_speech: {
                    required: true,
                    maxlength: 25
                },
                lang_speech_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                lang_speech_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },

                behavior: {
                    required: true,
                    maxlength: 25
                },
                behavior_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                behavior_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },

                occupational: {
                    required: true,
                    maxlength: 25
                },
                occupational_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                occupational_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },

                ic: {
                    required: true,
                    maxlength: 25
                },
                ic_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                ic_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },

                ca: {
                    required: true,
                    maxlength: 25
                    
                },
                ca_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                ca_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },

                ot: {
                    required: true,
                    maxlength: 25
                
                },
                ot_rate: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                ot_subtotal: {
                    required: true,
                    maxlength: 25,
                    digits: true
                },
                
            },
            messages: {
                'from_name': {
                    required: "Please enter from name.",
                },                            
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "option_id") {                  
                    error.appendTo("#errorToShow");
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                var token = $('input[name="csrfmiddlewaretoken"]').val();                
                var user = $('#user').val();            

                var attendance = $('#attendance').val();
                var attendance_rate = $('#attendance_rate').val();
                var attendance_subtotal = $('#attendance_subtotal').val();

                var trt = $('#trt').val();
                var trt_rate = $('#trt_rate').val();
                var trt_subtotal = $('#trt_subtotal').val();

                var aide = $('#aide').val();
                var aide_rate = $('#aide_rate').val();
                var aide_subtotal = $('#aide_subtotal').val();

                var aid = $('#aid').val();
                var aid_rate = $('#aid_rate').val();
                var aid_subtotal = $('#aid_subtotal').val();

                var lang_speech = $('#lang_speech').val();
                var lang_speech_rate = $('#lang_speech_rate').val();
                var lang_speech_subtotal = $('#lang_speech_subtotal').val();

                var behavior = $('#behavior').val();
                var behavior_rate = $('#behavior_rate').val();
                var behavior_subtotal = $('#behavior_subtotal').val();

                var occupational = $('#occupational').val();
                var occupational_rate = $('#occupational_rate').val();
                var occupational_subtotal = $('#occupational_subtotal').val();

                var ic = $('#ic').val();
                var ic_rate = $('#ic_rate').val();
                var ic_subtotal = $('#ic_subtotal').val();

                var ca = $('#ca').val();
                var ca_rate = $('#ca_rate').val();
                var ca_subtotal = $('#ca_subtotal').val();

                var ot = $('#ot').val();
                var ot_rate = $('#ot_rate').val();
                var ot_subtotal = $('#ot_subtotal').val();

                let csrftoken = '{{ csrf_token }}'
                $.ajax({
                    url: "/invoice-details-save/",
                    type: "POST",
                    headers:{'X-CSRFToken':token},
                    data:{
                        'user': user, 
                        'total': $('#total').val(),
                        
                        'attendance': attendance,
                        'attendance_rate': attendance_rate,
                        'attendance_subtotal': attendance_subtotal,

                        'trt': trt,
                        'trt_rate': trt_rate,
                        'trt_subtotal': trt_subtotal,

                        'aide': aide,
                        'aide_rate': aide_rate,
                        'aide_subtotal': aide_subtotal,

                        'aid': aid,
                        'aid_rate': aid_rate,
                        'aid_subtotal': aid_subtotal,

                        'lang_speech': lang_speech,
                        'lang_speech_rate': lang_speech_rate,
                        'lang_speech_subtotal': lang_speech_subtotal,

                        'behavior': behavior,
                        'behavior_rate': behavior_rate,
                        'behavior_subtotal': behavior_subtotal,

                        'occupational': occupational,
                        'occupational_rate': occupational_rate,
                        'occupational_subtotal': occupational_subtotal,

                        'ic': ic,
                        'ic_rate': ic_rate,
                        'ic_subtotal': ic_subtotal,

                        'ca': ca,
                        'ca_rate': ca_rate,
                        'ca_subtotal': ca_subtotal,

                        'ot': ot,
                        'ot_rate': ot_rate,
                        'ot_subtotal': ot_subtotal
                        
                    },
                    cache: false,
                    // beforeSend: function() { 
                    //     $("#user-list-assigned").html("<br /><br /><strong>Loading.....</strong><br /><br />");
                    // },
                    success: function(data) {
                        if(data.error == "1"){
                            $().msgpopup({
                                text: data.msg,
                                success: false, // false
                                time: 2000, // or false
                                x: true, // or false
                            });
                        } else {
                            if(data.is_staff == true){
                                window.location.href = '/invoice-basic-info';
                            } else {
                                window.location.href = '/invoice-details';
                            }
                        }
                        
                        // alert(data);
                        // window.location.href = '/';
                    },
                    complete:function(jqXhr){
                        $(".loaderDiv").hide();
                        // redirectLogin(jqXhr)
                    }
                }); 
            }
        });   
        
    });
});



// Image preview function
function previewImage(event) {
    const input = event.target;
    const previewId = input.name + 'Preview';
    const preview = document.getElementById(previewId);

    if (input.files && input.files[0]) {
        const reader = new FileReader();

        reader.onload = function(e) {
            preview.src = e.target.result; // Update preview image source
        };

        reader.readAsDataURL(input.files[0]); // Read the uploaded file as a data URL
    }
}

// Add event listener to file input elements
document.querySelectorAll('.image-preview-input').forEach(input => {
    input.addEventListener('change', previewImage);
});
