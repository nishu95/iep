# myapp/templatetags/custom_filters.py
from django import template
from datetime import datetime

register = template.Library()    

@register.filter
def format_date(value, date_format="%d-%b-%Y"):
    """Convert a date string or datetime object to a different format."""
    if isinstance(value, str):
        try:
            date_obj = datetime.strptime(value, "%Y-%m-%d")
        except ValueError:
            return value
    elif isinstance(value, datetime):
        date_obj = value
    else:
        return value
    return date_obj.strftime(date_format)


@register.filter
def startswith(value, arg):
    return value.startswith(arg)
