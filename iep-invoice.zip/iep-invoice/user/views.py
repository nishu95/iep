from django.shortcuts import render, redirect
from django.http import JsonResponse, response
from datetime import datetime
from django.utils.dateformat import DateFormat
from django.utils.formats import get_format
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
import requests
import json
from django.template.loader import render_to_string
import pdfkit
from django.http import HttpResponse
from IEPInvoice.functions import *
from .models import (
    User, BasicInfo, invoiceDetails,Service,Group,GroupByMonth, PDFInvoice
)
from django.utils import timezone
import datetime
from .form import invoiceDetailsForm
from django.db.models import Sum
from user.decorators import superuser_required
from django.views.decorators.csrf import csrf_exempt

from xhtml2pdf import pisa
import tempfile
import os
from django.template.loader import get_template
from io import BytesIO

def get_current_month():
    current_datetime = timezone.now()  # Get the current datetime in the timezone set in Django settings
    current_month = current_datetime.month  # Extract the month from the current datetime
    return current_month

def get_current_year():
    current_year = timezone.now().year  
    return current_year

def index(request):
    context = {}
    if 'userSess' in request.session:
    # if 'email' in request.session:
        return redirect('/invoice-basic-info')
    else:
        return render(request, 'web/index.html', context)

# def signup(request):
#     context = {}
#     if 'userSess' not in request.session:
#         # print("Seesion")
#         return redirect('/')
#     if request.POST:
#         post = request.POST
#         user_type_instance = UserType.objects.get(id=user_type)
#         password = post.get("password")
#         user_data = {
#             "email":post.get("email"),
#             "user_type":user_type_instance,
#             "mobile":post.get("mobile"),
#             "is_staff":True,
#         }
#         print("data",user_data)
#         try:
#             queryset = User.objects.create(**user_data)
#             queryset.set_password(password)
#             queryset.save()
#             context['message'] = "Data Add Successfully"
#             return render(request, 'web/index.html', context)
#         except Exception as e:
#             context['error'] = str(e)
#         return render(request, 'web/signup.html', context)
#     return render(request, 'web/signup.html', context)


@superuser_required
def signup(request):
    context = {}
    if 'userSess' not in request.session:
        print("Seesion")
        return redirect('/')
    if request.POST:
        post = request.POST
        
        password = post.get("password")
        email = post.get("email")
        print("emailkkk", email)
        mobile = post.get("mobile")
        user_data = {
            "name" : post.get("name"),
            "email":email,
            "mobile":mobile,
            "is_staff":True,
        }
        print("data",user_data)
        if User.objects.filter(email=email).exists():
            messages.error(request, "This email address already in use")
            return render(request, 'web/add-staff.html', context)
        
        if User.objects.filter(mobile=mobile).exists():
            messages.error(request, "This mobile number already in use")
            return render(request, 'web/add-staff.html', context)
        try:
            queryset = User.objects.create(**user_data)
            queryset.set_password(password)
            queryset.save()
            messages.success(request, "Staff Add Successfully")
            # context['message'] = "Staff Add Successfully"
            return redirect('staff_list')
        except Exception as e:
            context['error'] = str(e)
        return render(request, 'web/add-staff.html', context)
    return render(request, 'web/add-staff.html', context)

def forgot(request):
    context = {}
    return render(request, 'web/forgot.html', context)




@superuser_required
def staffListView(request):
    
    try:
        context = {}
        users = User.objects.filter(is_superuser= False)
        context['users'] = users
        # print(users, "users")
        return render(request, 'web/staff-list.html', context)
    except Exception as e:
        printException()
        messages.error(request, str(e))
    

@superuser_required
def deleteStaff(request,id):
    try:
        get_staff  = User.objects.get(id=id)
        get_staff.delete()
        messages.success(request, "Staff Delete Successfully")
        return redirect('staff_list')
    except Exception as e:
        printException()
        messages.success(request, str(e))
        return redirect('staff_list')



@superuser_required
def deletePdf(request,id):
    try:
        get_pdf  = PDFInvoice.objects.get(id=id)
        get_pdf.delete()
        messages.success(request, "Invoice Delete Successfully")
        return redirect('download_invoice_list')
    except Exception as e:
        printException()
        messages.success(request, str(e))
        return redirect('download_invoice_list')
    

# def deletePdf(request):
#     if request.method == 'GET':
#         pdf_id = request.GET['pdf_id']
#         print("jkjhhjkhkj", pdf_id)
#         get_pdf = PDFInvoice.objects.get(pk=pdf_id) #getting the id
#         get_pdf.delete()
#     #   return HttpResponse("Success!") # Sending an success response
#         return JsonResponse({'success': True, 'message': 'Delete successfully!'})
#     else:
#         return JsonResponse({'success': False, 'message': 'Invalid request'})
    


@superuser_required
def reset_staff_password(request, id):  
    context = {}
    if request.method == "POST":
        try:
            password = request.POST.get('password')
            queryset = User.objects.get(pk=id)
            queryset.set_password(password)
            queryset.save()
            messages.success(request, 'Password reset successfully')
            return redirect('staff_list')
        
        except Exception as e:
            printException()
            messages.success(request, str(e))
            return render(request, 'web/reset-staff-password.html', context)
    return render(request, 'web/reset-staff-password.html', context)


   

# def invoiceDetailsView(request):
#     if 'userSess' not in request.session:
#         return redirect('/')
#     if 'month_session' not in request.session:
#         inv_month = datetime.now().month  # current month
#         request.session['month_session'] = inv_month
#         month_session = inv_month
#     else:
#         inv_month = request.session['month_session']
#         month_session = request.session['month_session']
#     print("session month:", inv_month)
#     inv_users = invoiceDetails.objects.filter(month=inv_month).values_list('user_id', flat=True)
#     print("inv_users:", inv_users)
#     avail_users = User.objects.filter(is_staff=1).exclude(id__in=inv_users).order_by("-id")
#     invoice_users = invoiceDetails.objects.filter(month=inv_month)
#     print("avail_users:", avail_users)
#     print("invoice_users:", invoice_users)
    
#     context = {
#         "avail_users" : avail_users,
#         "invoice_users" : invoice_users,
#         "month_session" : settings.MONTHS[4]
#     }
#     return render(request, 'web/invoice-details.html', context)


# def invoiceBasicInfo(request):
#     if 'userSess' not in request.session:
#         return redirect('/')
#     if 'month_session' in request.session:
#         del request.session['month_session']
#     context = {}
#     return render(request, 'web/invoice-basic-info.html', context)


def logout_view(request):
    request.session.flush()
    for key in request.session.keys():
        del request.session[key]
    return redirect('/')

# def login(request):
#     requestData = request.body.decode('utf-8')
#     email = request.POST.get("email")
#     password = request.POST.get("password")
#     print("email:", email)
#     print("password:", password)
#     try:
#         user = User.objects.get(email=email)
        
#         print("user:", user)
#         if not user.check_password(password):
#             context = {          
#                 'error': 1,
#                 'msg' : "Invalid Password"      
#             }
#         else:
#             request.session['userSess'] = user.id
#             request.session['email'] = user.email
#             print("userSess", request.session['userSess'])
#             context = {          
#                 'error': 0,
#                 'is_staff': user.is_staff,
#                 'is_superuser': user.is_superuser,
#                 'msg': 'success'      
#             }
        
#     except Exception as e:
#         context = {          
#             'error': 1,
#             'msg' : "Email doesn't exist"      
#         }  
    
#     print(context)
#     return JsonResponse(context)




def login(request):
    if request.method != 'POST':
        return JsonResponse({'error': 1, 'msg': 'Invalid request method'}, status=405)
    
    email = request.POST.get("email")
    password = request.POST.get("password")

    if not email or not password:
        return JsonResponse({'error': 1, 'msg': 'Email and password are required'}, status=400)
    
    try:
        user = User.objects.get(email=email)
        
        user = authenticate(request, email=email, password=password)
        
        if user is not None:
            request.session['userSess'] = user.id
            request.session['is_superuser'] = user.is_superuser
            request.session['email'] = user.email
            # print("email", request.session['email'])
            # print("usersess", request.session['userSess'])
            context = {          
                'error': 0,
                'is_staff': user.is_staff,
                'is_superuser': user.is_superuser,
                'msg': 'success'      
            }
            # print(f"Session data: {request.session.items()}")
            # print(f"Authenticated user: {user.email}, is_staff: {user.is_staff}, is_superuser: {user.is_superuser}")
        else:
            context = {          
                'error': 1,
                'msg': 'Invalid Password'      
            }
    except User.DoesNotExist:
        context = {          
            'error': 1,
            'msg': "Email doesn't exist"      
        }
    
    return JsonResponse(context)




""" Master Models Views """
@superuser_required
def serviceListView(request):
    context = {}
    if 'userSess' not in request.session:
        return redirect('/')
    
    try:
        queryset = Service.objects.filter(is_active=True)
        context['service'] = queryset
        

        print(context,"service")
    except Exception as e:
        printException()
        context['error'] = str(e)

    
    return render(request, 'web/service_list.html', context)


def serviceAdd(request,id=None):
    context = {}
    if 'userSess' not in request.session:
        return redirect('/')
    
    try:
        if request.method == 'POST':
            post_data = request.POST.dict()  # Convert QueryDict to a dictionary
            print("post_data:", post_data)

            service_id = post_data.get('id')
            if service_id:
                # Update an existing service
                # try:
                    service = Service.objects.get(id=service_id)
                    for key, value in post_data.items():
                        setattr(service, key, value)
                    service.save()
                    obj = service
                    messages.success(request, "Record Updated Successfully")
                    return redirect('service_list')
                # except Service.DoesNotExist:
                    context['error'] = "Record Not Found"
                    
            else:
                # Create a new service
                if 'id' in post_data:
                    del post_data['id']
                    del post_data['csrfmiddlewaretoken']  # Remove 'id' key from post_data
                try:
                    obj = Service.objects.create(**post_data)
                    messages.success(request, "Record Add Successfully")
                    return redirect('service_list')
                except Exception as e:
                    printException()
                    context['error'] = str(e)

        if id:
            queryset = Service.objects.get(id=id)
            context['data'] = queryset
        

        # print(context,"service")
    except Exception as e:
        printException()
        context['error'] = str(e)

    
    return render(request, 'web/add-service.html', context)

def deleteService(request,id):
    try:
        obj  = Service.objects.get(id=id)
        obj.delete()
        messages.success(request, "Record Delete Successfully")
        return redirect('service_list')
    except Exception as e:
        printException()
        messages.success(request, str(e))
        return redirect('service_list')


""" Master Group Models Views """
# def groupListView(request):
#     context = {}
#     if 'userSess' not in request.session:
#         return redirect('/')
    
#     try:
#         queryset = Group.objects.filter(is_active=True)
#         context['group'] = queryset
        

#         print(context,"group")
#     except Exception as e:
#         printException()
#         context['error'] = str(e)

    
#     return render(request, 'web/group-list.html', context)

def groupListView(request):
    context = {}
    group=[]

    if 'userSess' not in request.session:
        return redirect('/')
    
    try:
        queryset = Group.objects.filter(is_active=True)
        for item in queryset:
            group_data = {
                'invoice_date': item.created_at.strftime('%d-%b-%Y'),
                'group_id': item.id,
                'group_name': item.name,
            }
            group.append(group_data)

        context['group'] = group
        context['ses'] = request.session.get('userSess')
        # print(context,"group")
    except Exception as e:
        printException()
        context['error'] = str(e)

    
    return render(request, 'web/group-list.html', context)



def groupAdd(request,id=None):
    context = {}
    if 'userSess' not in request.session:
        return redirect('/')
    
    try:
        if request.method == 'POST':
            post_data = request.POST.dict()  # Convert QueryDict to a dictionary
            group_name = post_data.get('name')
            print("post_data:", post_data)

            group_id = post_data.get('id')
            if group_id:
                # Update an existing service
                try:
                    if Group.objects.filter(name=group_name).exists():
                        messages.error(request, 'This Group Already Exists')
                        return redirect('group_list')
                    else:
                        group = Group.objects.get(id=group_id)
                        for key, value in post_data.items():
                            setattr(group, key, value)
                        group.save()
                        obj = group
                        messages.success(request, "Record Updated Successfully")
                        return redirect('group_list')
                except group.DoesNotExist:
                    context['error'] = "Record Not Found"
                    
            else:
                # Create a new service
                if 'id' in post_data:
                    del post_data['id']
                    del post_data['csrfmiddlewaretoken']  # Remove 'id' key from post_data
                try:
                    if Group.objects.filter(name=group_name).exists():
                        messages.error(request, 'This Group Already Exists')
                        return redirect('group_list')
                    else:
                        obj = Group.objects.create(**post_data)
                        messages.success(request, "Record Add Successfully")
                        return redirect('group_list')
                except Exception as e:
                    printException()
                    context['error'] = str(e)

        if id:
            queryset = Group.objects.get(id=id)
            context['data'] = queryset
        

        # print(context,"service")
    except Exception as e:
        printException()
        context['error'] = str(e)

    
    return render(request, 'web/add-group.html', context)



def deleteGroup(request,id):
    try:
        obj  = Group.objects.get(id=id)
        obj.delete()
        # obj.is_active=False 
        # obj.save()
        messages.success(request, "Record Delete Successfully")
        return redirect('group_list')
    except Exception as e:
        printException()
        messages.success(request, str(e))
        return redirect('group_list')



'''
    Basic Information Invoice Details, Accordingly month and year
'''
def invoiceBasicInfo(request):
    context = {}
    if 'userSess' not in request.session:
    # if 'email' not in request.session:
        return redirect('/')
    if 'month_session' in request.session:
        del request.session['month_session']
    current_month = int(get_current_month())
    base_url = request.build_absolute_uri()
    split_url = base_url.split('/')
    context['end_point'] = split_url[3]
    try:
        current_month = int(get_current_month())
        # basic_info_obj = BasicInfo.objects.get(month=current_month)
        basic_info_obj = BasicInfo.objects.get(pk=1)
        context['data'] = basic_info_obj
        context['invoice_date'] = basic_info_obj.invoice_date.strftime('%Y-%m-%d')
        context['invoice_period_from'] = basic_info_obj.invoice_period_from.strftime('%Y-%m-%d')
        context['invoice_period_to'] = basic_info_obj.invoice_period_to.strftime('%Y-%m-%d')
        context['month'] = basic_info_obj.month
        # print(basic_info_obj.invoice_date,"iprepared_by")

        # print(context,"current_month")
    except Exception as e:
        printException()
        context['month'] = current_month
        context['error'] = str(e)

    
    return render(request, 'web/invoice-basic-info.html', context)

'''
    Details Changes
'''
def invoiceBasicDetail(request,month,year):
    context = {}
    if 'userSess' not in request.session:
        return redirect('/')
    if 'month_session' in request.session:
        del request.session['month_session']
    
    try:
        print("month",month)
        basic_info_obj = BasicInfo.objects.get(month=month,year=year)
        context['data'] = basic_info_obj
        context['invoice_date'] = basic_info_obj.invoice_date.strftime('%Y-%m-%d')
        context['invoice_period_from'] = basic_info_obj.invoice_period_from.strftime('%Y-%m-%d')
        context['invoice_period_to'] = basic_info_obj.invoice_period_to.strftime('%Y-%m-%d')
        context['month'] = basic_info_obj.month
        # print(basic_info_obj.invoice_date,"iprepared_by")

        # print(context,"current_month")
    except Exception as e:
        printException()
        # context['month'] = current_month
        context['error'] = str(e)

    
    return render(request, 'web/basicInfoDetail.html', context)


def invoiceTemplate(request):
    context = {}
    context['domain_url'] = settings.BASE_URL
    base_url = request.build_absolute_uri()
    split_url = base_url.split('/')
    context['end_point'] = split_url[3]
    formatted_data = []
    year = int(get_current_year())
    queryset = BasicInfo.objects.filter(year=year)
    # formatted_data = [{'created_at': item.created_at.strftime('%d-%b-%Y'),'invoice_date':item.invoice_date,'id':item.id,'year':item.year,'month':item.month,"month_session":settings.MONTHS[item.month]} for item in queryset]
    for item in queryset:
        total = invoiceDetails.objects.filter(year=item.year,month=item.month).aggregate(total=Sum('total'))['total']
        if not total:
            total = 0

        fdata = {'created_at': item.updated_at.strftime('%d-%b-%Y'),'invoice_date':item.invoice_date,'id':item.id,'year':item.year,'month':item.month,"month_session":settings.MONTHS[item.month],'total':total}
        formatted_data.append(fdata)

    # print("formatted_data",formatted_data)

    context['basic_info'] = formatted_data
    # context['invoice_info'] = formatted_data
    print("context['domain_url']",context['domain_url'])
    return render(request, 'web/invoice-template-list.html', context)
'''
    Basic Information For Save Invoice Details Month,Year basis
'''
def basic_info_save(request):
    context = {}  # Initialize context dictionary
    # Extract data from POST request
    if request.POST:
        post = request.POST
        # print(post)
    else:
        context['error'] = "POST method is allowed"
    try:
        current_month = int(get_current_month())
        year = int(get_current_year())
        print("current_month",current_month)
        month = request.POST.get("month")
        if month:
            month  = int(month)
        else:
            month = current_month
        print("month",month)
        from_name = request.POST.get("from_name")
        to_name = request.POST.get("to_name")
        from_address = request.POST.get("from_address")
        to_address = request.POST.get("to_address")
        invoice_date = request.POST.get("invoice_date")
        logo = request.FILES.get('logo')
        approved_by = request.FILES.get('approved_by')
        prepared_by = request.FILES.get('prepared_by')
        invoice_period_from = request.POST.get("invoice_period_from")
        invoice_period_to = request.POST.get("invoice_period_to")
        approved_by_detail = request.POST.get("approved_by_detail")
        prepared_by_detail = request.POST.get("prepared_by_detail")
        # Check if required fields are present
        # if not all([month, from_name, to_name, invoice_date, invoice_period_from, invoice_period_to]):
        if not all([month, from_name, to_name]):
            raise ValueError("Missing required fields")
            context['error'] = "[month, from_name, to_name, invoice_date, invoice_period_from, invoice_period_to] is required"
        # Check if BasicInfo for the month already exists
        if BasicInfo.objects.filter(month=month,year=year).exists():
            # If exists, update the existing entry
            basic_info_obj = BasicInfo.objects.get(month=month,year=year)
        else:
            # If doesn't exist, create a new entry
            basic_info_obj = BasicInfo(month=month,year=year)
        # Update or set fields
        if logo: 
            basic_info_obj.logo = logo
        if approved_by:
            basic_info_obj.approved_by = approved_by
        if prepared_by: 
            basic_info_obj.prepared_by = prepared_by
        basic_info_obj.from_name = from_name
        basic_info_obj.to_name = to_name
        basic_info_obj.from_address = from_address
        basic_info_obj.to_address = to_address
        # basic_info_obj.invoice_date = invoice_date
        
        
        # basic_info_obj.invoice_period_from = invoice_period_from
        # basic_info_obj.invoice_period_to = invoice_period_to
        basic_info_obj.year = year
        basic_info_obj.approved_by_detail = approved_by_detail
        basic_info_obj.prepared_by_detail = prepared_by_detail
        # Save the object
        basic_info_obj.save()
        # Set session variable for month
        request.session['month_session'] = month
        # Redirect to invoice details page
        return redirect('/invoice-details/')
    except Exception as e:
        print("Error:", e)
        printException()
        context['error'] = str(e)
    return redirect('/')  # Redirect to home or error page


'''
    Get Basic Information For Invoice Details Month,Year basis through Ajax
'''
def getBasicDetails(request, id):
    print("month id:", id)
    context = {}
    infoData = []
    try:
        month = int(id)
        year = int(get_current_year())
        # infoObj = BasicInfo.objects.filter(month=month).latest('-id')
        infoObj = BasicInfo.objects.get(month=month,year=year)
        # print("infoObj:", infoObj.from_name)
        infoData =  {
                        "id": infoObj.id,
                        "from_name": infoObj.from_name,
                        "to_name": infoObj.to_name,
                        "from_address": infoObj.from_address,
                        "to_address": infoObj.to_address,
                        "logo": str(infoObj.logo),
                        "month": infoObj.month,
                        "invoice_date":infoObj.invoice_date,
                        "invoice_period_from": infoObj.invoice_period_from,
                        "invoice_period_to": infoObj.invoice_period_to,
                        "approved_by": str(infoObj.approved_by),
                        "prepared_by": str(infoObj.prepared_by),
                        "prepared_by_detail":infoObj.prepared_by_detail,
                        "approved_by_detail":infoObj.approved_by_detail
                    }
       
        # print("infoData:", infoData)
        context = {
            "error:": 0,
            "data_list":infoData,
        }
        response = {"success": True, "data": infoData, "message": "successfully"};
        return JsonResponse(response)
        # return JsonResponse(context)
    except Exception as e:
        print(e)
        printException()
        context = {
            "error:": 1
        }
        response = {"success": False, "error": str(e), "message": "Record not found"};
        return JsonResponse(response)
        # return JsonResponse(context)



'''
    Save Single Student Invoice Information 
'''
# def single_student_save(request):
#     try:
#         if request.method == 'POST':
#             post = request.POST.copy()  # Create a mutable copy
#             print("Post", post)
#             user_id = request.POST.get("user")
#             student_name = post.get('student_name')
#             month = int(get_current_month())
#             year = int(get_current_year())
#             sv_id = post.get('id', None)

#             # Check if student already exists for the current month and year
#             queryset = invoiceDetails.objects.filter(month=month, year=year, student_name=student_name)
#             if sv_id:
#                 queryset = queryset.exclude(id=sv_id)
#             else:
#                 del post['id']

#             if queryset.exists():
#                 response = {"success": False, "error": "", "message": f"Student {student_name} already exists for the current month and year"}
#                 print("response", response)
#                 return JsonResponse(response)

#             # Calculate total and subtotals
#             total = 0
#             fields = ['attendance', 'trt', 'aide', 'aid', 'lang_speech', 'behavior', 'occupational', 'ic', 'ca', 'ot']
#             for field in fields:
#                 rate = float(post.get(f'{field}_rate', 0))
#                 periods = float(post.get(f'{field}_periods', 0))
#                 subtotal = rate * periods
#                 total += subtotal
#                 post[f'{field}_subtotal'] = subtotal

#             # Save or update invoice details
#             defaults = {
#                 'user_id': user_id,
#                 'month': month,
#                 'year': year,
#                 'total': total,
#             }
#             if sv_id:
#                 invoice_details_obj, created = invoiceDetails.objects.update_or_create(id=sv_id, defaults=post)
#             else:
#                 print("defaults",defaults,"---post",post)
#                 invoice_details_obj = invoiceDetails.objects.create(**defaults, **post)

#             context = {
#                 "error": 0,
#                 "data_list": invoice_details_obj,
#             }
#             response = {"success": True, "data": "True", "message": "Record saved successfully"}
#             print("response", response)
#             return JsonResponse(response)

#     except Exception as e:
#         print(e)
#         printException()
#         context = {
#             "error": 1
#         }
#         response = {"success": False, "error": str(e), "message": "Record not found"}
#         print("response", response)
#         return JsonResponse(response)


def single_student_save(request):
    context = {}
    try:
        if request.method == 'POST':
            post = request.POST 
            print("Post",post)
            group = post.get('group')
            print("groupst",group)
            invoice_date = post.get('invoice_date')
            inv_date = invoice_date
            d = inv_date.split("-")
            print(d,"split date")
            user_id = request.POST.get("user")
            student_name = post.get('student_name')
            total = request.POST.get("total")
            month = int(d[1])
            year = int(d[0])
            sv_id = post.get('id',None)
            print("month ",month,"---Year ",year)

            if not group:
                response = {"success": False, "error": "", "message": "Please select group"};
                # print("response",response)
                return JsonResponse(response)

            if not student_name:
                response = {"success": False, "error": "", "message": "Please enter student name"};
                # print("response",response)
                return JsonResponse(response)

            if not invoice_date:
                response = {"success": False, "error": "", "message": "Please select invoice date"};
                # print("response",response)
                return JsonResponse(response)


            if sv_id:
                queryset = invoiceDetails.objects.filter(invoice_date= inv_date,student_name=student_name).exclude(student_name=student_name)
                # print("ifqueryset", queryset)
            else:
                queryset = invoiceDetails.objects.filter(group=group, student_name=student_name)
            # print("queryset",queryset)
            if len(queryset) > 0:
                response = {"success": False, "error": "", "message": "Student "+student_name+" is already exists with selected group"};
                # print("response",response)
                return JsonResponse(response)



            attendance = request.POST.get("attendance")
            attendance_rate = request.POST.get("attendance_rate",0)
            attendance_periods = request.POST.get("attendance_periods",0)
            attendance_subtotal = float(attendance_rate)*float(attendance_periods)

            trt = request.POST.get("trt")
            trt_rate = request.POST.get("trt_rate",0)
            trt_periods = post.get("trt_periods",0)
            trt_subtotal = float(trt_rate)*float(trt_periods)

            aide = request.POST.get("aide")
            aide_rate = request.POST.get("aide_rate",0)
            aide_periods = post.get("aide_periods",0)
            aide_subtotal = float(aide_rate)*float(aide_periods)

            aid = request.POST.get("aid")
            aid_rate = request.POST.get("aid_rate",0)
            aid_periods = post.get("aid_periods",0)
            aid_subtotal = float(aid_rate)*float(aid_periods)

            lang_speech = request.POST.get("lang_speech")
            lang_speech_rate = request.POST.get("lang_speech_rate",0)
            lang_speech_periods = post.get("lang_speech_periods",0)
            lang_speech_subtotal = float(lang_speech_rate)*float(lang_speech_periods)

            behavior = request.POST.get("behavior")
            behavior_rate = request.POST.get("behavior_rate",0)
            behavior_periods = post.get("behavior_periods",0)
            behavior_subtotal = float(behavior_rate)*float(behavior_periods)

            occupational = request.POST.get("occupational")
            occupational_rate = request.POST.get("occupational_rate",0)
            occupational_periods = post.get("occupational_periods",0)
            occupational_subtotal = float(occupational_rate)*float(occupational_periods)

            ic = request.POST.get("ic")
            ic_rate = request.POST.get("ic_rate",0)
            ic_periods = post.get("ic_periods",0)
            ic_subtotal = float(ic_rate)*float(ic_periods)

            ca = request.POST.get("ca")
            ca_rate = request.POST.get("ca_rate",0)
            ca_periods = post.get("ca_periods",0)
            ca_subtotal = float(ca_rate)*float(ca_periods)

            ot = request.POST.get("ot")
            ot_rate = request.POST.get("ot_rate",0)
            ot_periods = post.get("ot_periods",0)
            ot_subtotal = float(ot_rate)*float(ot_periods)

            total = (float(attendance_subtotal) + float(trt_subtotal) + float(aide_subtotal) + float(aid_subtotal) + float(lang_speech_subtotal) + float(behavior_subtotal) + float(occupational_subtotal) + float(ic_subtotal) + float(ca_subtotal) + float(ot_subtotal))

            # print("ot",attendance,"--ot_rate",attendance_rate,"--ot_periods",attendance_periods,"--ot_subtotal",attendance_subtotal,"--total",total,"-- invoice_date",invoice_date)
            
            try:
                if sv_id:
                    basicObj = invoiceDetails.objects.get(id=sv_id)
                else:
                    basicObj = invoiceDetails(user_id=user_id,student_name=student_name)

                basicObj.user_id=user_id
                basicObj.student_name=student_name
                basicObj.month = month
                basicObj.total=total
                basicObj.attendance = attendance
                basicObj.attendance_rate = attendance_rate
                basicObj.attendance_periods = attendance_periods
                basicObj.attendance_subtotal = attendance_subtotal
                basicObj.trt = trt
                basicObj.trt_rate = trt_rate
                basicObj.trt_periods = trt_periods
                basicObj.trt_subtotal = trt_subtotal
                basicObj.aide = aide
                basicObj.aide_rate = aide_rate
                basicObj.aide_periods = aide_periods
                basicObj.aide_subtotal = aide_subtotal
                basicObj.aid = aid
                basicObj.aid_rate = aid_rate
                basicObj.aid_periods = aid_periods
                basicObj.aid_subtotal = aid_subtotal
                basicObj.lang_speech = lang_speech
                basicObj.lang_speech_rate = lang_speech_rate
                basicObj.lang_speech_periods = lang_speech_periods
                basicObj.lang_speech_subtotal = lang_speech_subtotal
                basicObj.behavior = behavior
                basicObj.behavior_rate = behavior_rate
                basicObj.behavior_periods = behavior_periods
                basicObj.behavior_subtotal = behavior_subtotal
                basicObj.occupational = occupational
                basicObj.occupational_rate = occupational_rate
                basicObj.occupational_periods = occupational_periods
                basicObj.occupational_subtotal = occupational_subtotal
                basicObj.ic = ic
                basicObj.ic_rate = ic_rate
                basicObj.ic_periods = ic_periods
                basicObj.ic_subtotal = ic_subtotal
                basicObj.ca = ca
                basicObj.ca_rate = ca_rate
                basicObj.ca_periods = ca_periods
                basicObj.ca_subtotal = ca_subtotal
                basicObj.ot = ot
                basicObj.ot_rate = ot_rate
                basicObj.ot_periods = ot_periods
                basicObj.ot_subtotal = ot_subtotal
                basicObj.year= year
                basicObj.group_id = group 
                basicObj.invoice_date = invoice_date
                basicObj.save()

                try:
                    group_obj = GroupByMonth.objects.get(group=group,invoice_date=invoice_date)
                    group_list = GroupByMonth.objects.filter(group=group,invoice_date=invoice_date)
                    group_list.update(is_downloaded=False)
                    # print("this is try")
                    
                except GroupByMonth.DoesNotExist:
                    # print("this is except")
                    GroupByMonth.objects.create(month=month,year=year,group_id=group,invoice_date=invoice_date)
                
            except Exception as e:
                printException()
                print("e=>", e)
        
            context = {
            "error:": 0,
            "data_list":basicObj,
        }
        response = {"success": True, "data": "True", "message": "Successfully"};
        # print("response",response)
        return JsonResponse(response)
        # return JsonResponse(context)
    except Exception as e:
        print(e)
        printException()
        context = {
            "error:": 1
        }
        response = {"success": False, "error": str(e), "message": "Record not found"};
        # print("response",response)
        return JsonResponse(response)

def studentServiceList(request,group_id):
    group = Group.objects.filter(is_active=True)
    context = {}
    year = int(get_current_year())
    month = int(get_current_month())
    infoObj_queryset = invoiceDetails.objects.filter(month=month,year=year,group=group_id).order_by('-id')
    service_obj = Service.objects.filter(is_active=True)

    student_info = []
    for infoObj in infoObj_queryset:
        services = []
        for s in service_obj:
            service_data = {
                "id": s.id,
                "service_name": s.service_name,
                "service_rate": s.service_rate,
                "key_title": s.key_title,
                "key_period": s.key_period,
                "key_rate": s.key_rate,
                "key_subtotal": s.key_subtotal,
                "student_name": infoObj.student_name
            }

            if hasattr(infoObj, s.key_title):
                service_data.update({
                    "title": getattr(infoObj, s.key_title),
                    "periods": getattr(infoObj, f"{s.key_title}_periods"),
                    "rate": getattr(infoObj, f"{s.key_title}_rate"),
                    "subtotal": getattr(infoObj, f"{s.key_title}_subtotal")
                })
            services.append(service_data)

        student_info.append({
            "id":infoObj.id,
            "student_name": infoObj.student_name,
            "month": infoObj.month,
            "year": infoObj.year,
            "total": infoObj.total,
            "created_at": infoObj.created_at,
            "services": services
        })

        # print("student_info",student_info)
    
    context['student_info'] = student_info
    context['domain_url']= settings.BASE_URL
    context['group'] = group
    context['group_id'] = group_id
    # return render(request, 'web/student-invoice-list.html', context)
    return render(request, 'web/student-service-list.html', context)



def studentServiceDetail(request, id):
    context = {}
    try:
        infoObj = invoiceDetails.objects.get(id=id)
        service_obj = Service.objects.filter(is_active=True)
        services = []
        for s in service_obj:
            dicts = {
                "id": s.id,
                "service_name": s.service_name,
                "service_rate": s.service_rate,
                "key_title": s.key_title,
                "key_period": s.key_period,
                "key_rate": s.key_rate,
                "key_subtotal": s.key_subtotal,
                "student_name": infoObj.student_name
            }
            # Update dictionaries based on key_title
            if s.key_title == "attendance":
                dicts.update({"title": infoObj.attendance, "periods": infoObj.attendance_periods, "rate": infoObj.attendance_rate, "subtotal": infoObj.attendance_subtotal})
            elif s.key_title == "trt":
                dicts.update({"title": infoObj.trt, "periods": infoObj.trt_periods, "rate": infoObj.trt_rate, "subtotal": infoObj.trt_subtotal})
            elif s.key_title == "aide":
                dicts.update({"title": infoObj.aide, "periods": infoObj.aide_periods, "rate": infoObj.aide_rate, "subtotal": infoObj.aide_subtotal})
            elif s.key_title == "aid":
                dicts.update({"title": infoObj.aid, "periods": infoObj.aid_periods, "rate": infoObj.aid_rate, "subtotal": infoObj.aid_subtotal})
            elif s.key_title == "lang_speech":
                dicts.update({"title": infoObj.lang_speech, "periods": infoObj.lang_speech_periods, "rate": infoObj.lang_speech_rate, "subtotal": infoObj.lang_speech_subtotal})
            elif s.key_title == "behavior":
                dicts.update({"title": infoObj.behavior, "periods": infoObj.behavior_periods, "rate": infoObj.behavior_rate, "subtotal": infoObj.behavior_subtotal})
            elif s.key_title == "occupational":
                dicts.update({"title": infoObj.occupational, "periods": infoObj.occupational_periods, "rate": infoObj.occupational_rate, "subtotal": infoObj.occupational_subtotal})
            elif s.key_title == "ic":
                dicts.update({"title": infoObj.ic, "periods": infoObj.ic_periods, "rate": infoObj.ic_rate, "subtotal": infoObj.ic_subtotal})
            elif s.key_title == "ca":
                dicts.update({"title": infoObj.ca, "periods": infoObj.ca_periods, "rate": infoObj.ca_rate, "subtotal": infoObj.ca_subtotal})
            elif s.key_title == "ot":
                dicts.update({"title": infoObj.ot, "periods": infoObj.ot_periods, "rate": infoObj.ot_rate, "subtotal": infoObj.ot_subtotal})

            services.append(dicts)

        
        context['student_name'] = infoObj.student_name
        context["id"] = infoObj.id
        context["group_id"] = infoObj.group.id
        context["invoice_date"] = infoObj.invoice_date.strftime('%Y-%m-%d')
        context['service'] = services
        context['head_text'] = "Update Student Details"
        # print("services", infoObj.invoice_date)
        group = Group.objects.filter(is_active=True)
        context['group'] = group


        return render(request, 'web/student-fill-invoice.html', context)
        

    except invoiceDetails.DoesNotExist:
        return HttpResponse("Invoice details not found for the given ID.")
    except Service.DoesNotExist:
        return HttpResponse("Service details not found.")
    except Exception as e:
        printException()
        return HttpResponse(f"An error occurred: {str(e)}")


def studentGroupList(request):
    context = {}
    if 'userSess' not in request.session:
        return redirect('/')
    
    try:
        queryset = Group.objects.filter(is_active=True)
        context['group'] = queryset
        

        print(context,"group")
    except Exception as e:
        printException()
        context['error'] = str(e)

    
    return render(request, 'web/student-group-list.html', context)



# def invoiceList(request):
#     context = {}
#     year = int(get_current_year())
#     # info_obj = BasicInfo.objects.filter()
#     queryset = GroupByMonth.objects.filter(year=year).order_by('-id')
#     formatted_data = [{'invoice_date': item.invoice_date.strftime('%d-%b-%Y'),'group_id':item.group.id,'group_name':item.group.name,'id':item.id,'year':item.year,'month':item.month,"month_session":settings.MONTHS[item.month],'inv_date': item.invoice_date.strftime('%Y-%m-%d')} for item in queryset]

#     # context['basic_info'] = info_obj
#     print("formatted_data",formatted_data)
#     context['invoice_info'] = formatted_data
    

#     return render(request, 'web/invoice-list.html', context)



def invoiceList(request):
    if 'userSess' not in request.session:
        return redirect('/')
    context = {}
    year = int(get_current_year())
    queryset = GroupByMonth.objects.filter(year=year, is_downloaded=False).order_by('-id')

    formatted_data = []

    for item in queryset:
        group_invoice_data = {
            'invoice_date': item.invoice_date.strftime('%d-%b-%Y'),
            'group_id': item.group.id,
            'group_name': item.group.name,
            'id': item.id,
            'year': item.year,
            'month': item.month,
            "month_session": settings.MONTHS[item.month],
            'inv_date': item.invoice_date.strftime('%Y-%m-%d')
        }

        student_info_queryset = invoiceDetails.objects.filter(invoice_date=item.invoice_date, group=item.group.id).order_by('-id')

        student_info = []
        unique_student_names = set()  # Set to store unique student names for this group

        for infoObj in student_info_queryset:
            unique_student_names.add(infoObj.student_name)  # Add student name to the set

            student_info.append({
                "id": infoObj.id,
                "student_name": infoObj.student_name,
                "month": infoObj.month,
                "year": infoObj.year,
                "total": infoObj.total,
                "created_at": infoObj.created_at,
                # "services": services
            })

        group_invoice_data['student_info'] = student_info
        group_invoice_data['unique_student_count'] = len(unique_student_names)  # Unique student count for perticular group
        formatted_data.append(group_invoice_data)

    context['invoice_info'] = formatted_data

    # return render(request, 'web/sample.html', context)
    return render(request, 'web/invoice-list.html', context)



@superuser_required
def downloadinvoiceList(request):
    if 'userSess' not in request.session:
        return redirect('/')
    context = {}
    all_pdf_data= PDFInvoice.objects.all()
    context['pdf_data'] = all_pdf_data
    return render(request, 'web/download-invoice-list.html', context)

    

def studentGroupInvoiceList(request,inv_date,group_id):
    
    context = {}
    year = int(get_current_year())
    month = int(get_current_month())
    infoObj_queryset = invoiceDetails.objects.filter(invoice_date=inv_date,group=group_id).order_by('-id')
    service_obj = Service.objects.filter(is_active=True)
    group = Group.objects.get(pk= group_id)
    group_name= group.name
    parsed_date = datetime.strptime(inv_date, "%Y-%m-%d")
    formatted_date = parsed_date.strftime("%d-%b-%Y")

    student_info = []
    for infoObj in infoObj_queryset:
        services = []
        for s in service_obj:
            service_data = {
                "id": s.id,
                "service_name": s.service_name,
                "service_rate": s.service_rate,
                "key_title": s.key_title,
                "key_period": s.key_period,
                "key_rate": s.key_rate,
                "key_subtotal": s.key_subtotal,
                "student_name": infoObj.student_name
            }

            if hasattr(infoObj, s.key_title):
                service_data.update({
                    "title": getattr(infoObj, s.key_title),
                    "periods": getattr(infoObj, f"{s.key_title}_periods"),
                    "rate": getattr(infoObj, f"{s.key_title}_rate"),
                    "subtotal": getattr(infoObj, f"{s.key_title}_subtotal")
                })
            services.append(service_data)

        student_info.append({
            "id":infoObj.id,
            "student_name": infoObj.student_name,
            "month": infoObj.month,
            "year": infoObj.year,
            "total": infoObj.total,
            "created_at": infoObj.created_at,
            "services": services
        })
    
        # print("student_info",student_info)

   
    context['student_info'] = student_info
    context['gp_inv_date'] = formatted_date
    context['gp_name'] = group_name

    return render(request, 'web/student-invoice-list.html', context)

'''
    Save Student Invoice Information 
'''
# Temporary not used
def invoice_details_save(request):
    if request.POST:
        post = request.POST 
        print("Post",post)
        user_id = request.POST.get("user")
        total = request.POST.get("total")
        month = request.session['month_session']
        year = int(get_current_year())
        # Check if required fields are present
        if not all([user_id, total, month]):
            raise ValueError("Missing required fields")
        
        attendance = request.POST.get("attendance")
        attendance_rate = request.POST.get("attendance_rate")
        attendance_subtotal = request.POST.get("attendance_subtotal")
        trt = request.POST.get("trt")
        trt_rate = request.POST.get("trt_rate")
        trt_subtotal = request.POST.get("trt_subtotal")
        aide = request.POST.get("aide")
        aide_rate = request.POST.get("aide_rate")
        aide_subtotal = request.POST.get("aide_subtotal")
        aid = request.POST.get("aid")
        aid_rate = request.POST.get("aid_rate")
        aid_subtotal = request.POST.get("aid_subtotal")
        lang_speech = request.POST.get("lang_speech")
        lang_speech_rate = request.POST.get("lang_speech_rate")
        lang_speech_subtotal = request.POST.get("lang_speech_subtotal")
        behavior = request.POST.get("behavior")
        behavior_rate = request.POST.get("behavior_rate")
        behavior_subtotal = request.POST.get("behavior_subtotal")
        occupational = request.POST.get("occupational")
        occupational_rate = request.POST.get("occupational_rate")
        occupational_subtotal = request.POST.get("occupational_subtotal")
        ic = request.POST.get("ic")
        ic_rate = request.POST.get("ic_rate")
        ic_subtotal = request.POST.get("ic_subtotal")
        ca = request.POST.get("ca")
        ca_rate = request.POST.get("ca_rate")
        ca_subtotal = request.POST.get("ca_subtotal")
        ot = request.POST.get("ot")
        ot_rate = request.POST.get("ot_rate")
        ot_subtotal = request.POST.get("ot_subtotal")
        total = (int(attendance_subtotal) + int(trt_subtotal) + int(aide_subtotal) + int(aid_subtotal) + int(lang_speech_subtotal) + int(behavior_subtotal) + int(occupational_subtotal) + int(ic_subtotal) + int(ca_subtotal) + int(ot_subtotal))
        
        try:
            basicObj = invoiceDetails(
                user_id=user_id,
                month = month,
                total=total,
                attendance = attendance,
                attendance_rate = attendance_rate,
                attendance_subtotal = attendance_subtotal,
                trt = trt,
                trt_rate = trt_rate,
                trt_subtotal = trt_subtotal,
                aide = aide,
                aide_rate = aide_rate,
                aide_subtotal = aide_subtotal,
                aid = aid,
                aid_rate = aid_rate,
                aid_subtotal = aid_subtotal,
                lang_speech = lang_speech,
                lang_speech_rate = lang_speech_rate,
                lang_speech_subtotal = lang_speech_subtotal,
                behavior = behavior,
                behavior_rate = behavior_rate,
                behavior_subtotal = behavior_subtotal,
                occupational = occupational,
                occupational_rate = occupational_rate,
                occupational_subtotal = occupational_subtotal,
                ic = ic,
                ic_rate = ic_rate,
                ic_subtotal = ic_subtotal,
                ca = ca,
                ca_rate = ca_rate,
                ca_subtotal = ca_subtotal,
                ot = ot,
                ot_rate = ot_rate,
                ot_subtotal = ot_subtotal,
                year= year
            )
            basicObj.save()
            
        except Exception as e:
            print("e=>", e)
    
        context = {}
        
    print(context)
    return JsonResponse(context)

'''
    Delete Student Invoice Information
'''
def deleteInvoiceData(request, id):
    print("id:", id)
    try:
        invoiceObj = invoiceDetails.objects.get(id=id)
        invoiceObj.delete()
        
        context = {          
            'error': 0,
            'msg' : "Delete Successfully"      
        }  
        
    except Exception as e:
        context = {          
            'error': 1,
            'msg' : "Something Went Wrong"      
        }  
    
    print(context)
    return JsonResponse(context)




'''
    show Student invoice where u can show details or add 
'''
def invoiceDetailsView(request):
    try:
        if 'userSess' not in request.session:
            return redirect('/')
        
        if 'month_session' not in request.session:
            inv_month = int(get_current_month())  # current month
            request.session['month_session'] = inv_month
        else:
            inv_month = request.session['month_session']
        
        year = int(get_current_year())

        # print("inv_month" , inv_month)
        
        inv_users = invoiceDetails.objects.filter(month=inv_month, year=year).values_list('user_id', flat=True)
        # print("inv_users:", inv_users)
        
        avail_users = User.objects.filter(is_staff=0).exclude(id__in=inv_users).order_by("-id")
        invoice_users = invoiceDetails.objects.filter(month=inv_month, year=year)
        group = Group.objects.filter(is_active=True)
        
        # print("avail_users:", avail_users)
        # print("invoice_users:", invoice_users)
        
        context = {
            "avail_users": avail_users,
            "invoice_users": invoice_users,
            "month_session": settings.MONTHS[inv_month],
            "year":year,
            "group":group,
            "head_text":"Add Student Details"
        }
        queryset = Service.objects.filter(is_active=True)
        context['service'] = queryset
        # print("context",context)
        
        # return render(request, 'web/invoice-details.html', context)
        return render(request, 'web/student-fill-invoice.html', context)
    except Exception as e:
        printException()
        redirect('/')


def invoiceHistory(request):
    context = {}
    year = int(get_current_year())
    # info_obj = BasicInfo.objects.filter()
    queryset = invoiceDetails.objects.filter(year=year)
    formatted_data = [{'created_at': item.created_at.strftime('%d-%b-%Y'),'total':item.total,'id':item.id,'year':item.year,'month':item.month,"month_session":settings.MONTHS[item.month]} for item in queryset]

    # context['basic_info'] = info_obj
    context['invoice_info'] = formatted_data
    

    return render(request, 'web/invoice-history.html', context)






# def downloadInvoice(request,month,year):
#     context = {}
#     try:
#         import pdfkit
#         from django.http import HttpResponse
#         print("month",month,"year",year)
#         context['data'] = invoiceDetails.objects.get(month=month,year=year)
     
#         html_content = render_to_string('web/invoice_pdf.html', context)
#         config = pdfkit.configuration(wkhtmltopdf='/usr/bin/wkhtmltopdf')
#         pdf = pdfkit.from_string(html_content, False, configuration=config)
#         response = HttpResponse(pdf, content_type='application/pdf')
#         response['Content-Disposition'] = 'attachment; filename="output.pdf"'
        
#         return response
#     except Exception as e:
#         printException()
#         return False

def downloadInvoice(request, month, year):
    
    try:
        # Query the invoice details based on the month and year
        invoice_data = invoiceDetails.objects.filter(month=month, year=year)
        invoice_info = BasicInfo.objects.get(month=month, year=year)
        
        # Prepare the context for rendering the HTML template
        context = {'invoice_data': invoice_data,"invoice_info":invoice_info}
        
        # Render the HTML template to a string
        html_content = render_to_string('web/demo.html', context)
        print("html_content",html_content)
        
        # Configure pdfkit
        config = pdfkit.configuration(wkhtmltopdf='/usr/bin/wkhtmltopdf')
        print("config",config)
        
        # Generate PDF from HTML content
        pdf = pdfkit.from_string(html_content, False, configuration=config)
        print("pdf",pdf)
        
        # Create an HTTP response with the PDF content
        filename = str(month) +"-" + str(year) +".pdf"
        print("filename",str(filename))
        response = HttpResponse(pdf, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="'+filename+'"'
        
        return response
    except Exception as e:
        printException()
        return HttpResponse("Invoice not found", status=404)
    except Exception as e:
        printException()
        print(e)  # Print the exception for debugging purposes
        return HttpResponse("An error occurred while generating the invoice", status=500)


from datetime import datetime

def pdf(request, invoice_date,group_id):
    context = {}
    # service_total = []

    # Filter the invoice details based on the invoice_date
    invoice_data = invoiceDetails.objects.filter(invoice_date=invoice_date, group=group_id)

    try:
        # Get the basic info, if it exists
        invoice_info = BasicInfo.objects.get(pk=1)
        print("Basicinfo", invoice_info)
    except BasicInfo.DoesNotExist:
        invoice_info = {}
    
    url = settings.MEDIA_ROOT
    invoice_date = datetime.strptime(invoice_date, "%Y-%m-%d")
    formatted_date = invoice_date.strftime("%B %Y")

    invoice_data_list = []
    
    for data in invoice_data:
        total_data = {
            
            'attendance_subtotal': data.attendance_subtotal,
            'trt_subtotal': data.trt_subtotal,
            'aide_subtotal': data.aide_subtotal,
            'aid_subtotal': data.aid_subtotal,
            'lang_speech_subtotal': data.lang_speech_subtotal,
            'behavior_subtotal': data.behavior_subtotal,
            'occupational_subtotal': data.occupational_subtotal,
            'ic_subtotal': data.ic_subtotal,
            'ca_subtotal': data.ca_subtotal,
            'ot_subtotal': data.ot_subtotal
        }
        total = sum(total_data.values())
        # service_total.append(total)
        
        # Convert the model instance to a dictionary
        data_dict = {
            'student_name' : data.student_name,
            "attendance_periods" : data.attendance_periods,
            'attendance_rate' : data.attendance_rate,
            'attendance_subtotal': data.attendance_subtotal,

            'trt_periods': data.trt_periods,
            'trt_rate': data.trt_rate,
            'trt_subtotal': data.trt_subtotal,

            'aide_periods': data.aide_periods,
            'aide_rate': data.aide_rate,
            'aide_subtotal': data.aide_subtotal,

            'aid_periods': data.aid_periods,
            'aid_rate': data.aid_rate,
            'aid_subtotal': data.aid_subtotal,

            'lang_speech_periods': data.lang_speech_periods,
            'lang_speech_rate': data.lang_speech_rate,
            'lang_speech_subtotal': data.lang_speech_subtotal,


            'behavior_periods': data.behavior_periods,
            'behavior_rate': data.behavior_rate,
            'behavior_subtotal': data.behavior_subtotal,

            'occupational_periods': data.occupational_periods,
            'occupational_rate': data.occupational_rate,
            'occupational_subtotal': data.occupational_subtotal,

            'ic_periods': data.ic_periods,
            'ic_rate': data.ic_rate,
            'ic_subtotal': data.ic_subtotal,
            

            'ca_periods': data.ca_periods,
            'ca_rate': data.ca_rate,
            'ca_subtotal': data.ca_subtotal,


            'ot_periods': data.ot_periods,
            'ot_rate': data.ot_rate,
            'ot_subtotal': data.ot_subtotal,

            'service_total': total  # Add the service total to the dictionary
        }

        invoice_data_list.append(data_dict)
    
    context = {
        'invoice_data': invoice_data_list,
        "invoice_info": invoice_info,
        'domain_url': settings.BASE_URL,
        'url': url,
        'formatted_date': formatted_date,
        'invoice_date': invoice_date,
        
    }
    
    return render(request, 'web/create-bill.html', context)

@superuser_required
def pdf_view(request, invoice_date,group_id):
    if 'userSess' not in request.session:
        return redirect('/')
    context = {}
    # service_total = []

    # Filter the invoice details based on the invoice_date
    invoice_data = invoiceDetails.objects.filter(invoice_date=invoice_date, group=group_id)
    gp = GroupByMonth.objects.get(invoice_date=invoice_date, group=group_id, is_downloaded=False)
    g = Group.objects.get(pk= gp.group_id)

    # print("jnjjk",g.name)
    

    try:
        # Get the basic info, if it exists
        invoice_info = BasicInfo.objects.get(pk=1)
        # print("Basicinfo", invoice_info)
    except BasicInfo.DoesNotExist:
        invoice_info = {}
    
    url = settings.MEDIA_ROOT
    invoice_date = datetime.strptime(invoice_date, "%Y-%m-%d")
    formatted_date = invoice_date.strftime("%B %Y")

    invoice_data_list = []
    
    for data in invoice_data:
        total_data = {
            
            'attendance_subtotal': data.attendance_subtotal,
            'trt_subtotal': data.trt_subtotal,
            'aide_subtotal': data.aide_subtotal,
            'aid_subtotal': data.aid_subtotal,
            'lang_speech_subtotal': data.lang_speech_subtotal,
            'behavior_subtotal': data.behavior_subtotal,
            'occupational_subtotal': data.occupational_subtotal,
            'ic_subtotal': data.ic_subtotal,
            'ca_subtotal': data.ca_subtotal,
            'ot_subtotal': data.ot_subtotal
        }
        total = sum(total_data.values())
        # service_total.append(total)
        
        # Convert the model instance to a dictionary
        data_dict = {
            'student_name' : data.student_name,
            "attendance_periods" : data.attendance_periods,
            'attendance_rate' : data.attendance_rate,
            'attendance_subtotal': data.attendance_subtotal,

            'trt_periods': data.trt_periods,
            'trt_rate': data.trt_rate,
            'trt_subtotal': data.trt_subtotal,

            'aide_periods': data.aide_periods,
            'aide_rate': data.aide_rate,
            'aide_subtotal': data.aide_subtotal,

            'aid_periods': data.aid_periods,
            'aid_rate': data.aid_rate,
            'aid_subtotal': data.aid_subtotal,

            'lang_speech_periods': data.lang_speech_periods,
            'lang_speech_rate': data.lang_speech_rate,
            'lang_speech_subtotal': data.lang_speech_subtotal,


            'behavior_periods': data.behavior_periods,
            'behavior_rate': data.behavior_rate,
            'behavior_subtotal': data.behavior_subtotal,

            'occupational_periods': data.occupational_periods,
            'occupational_rate': data.occupational_rate,
            'occupational_subtotal': data.occupational_subtotal,

            'ic_periods': data.ic_periods,
            'ic_rate': data.ic_rate,
            'ic_subtotal': data.ic_subtotal,
            

            'ca_periods': data.ca_periods,
            'ca_rate': data.ca_rate,
            'ca_subtotal': data.ca_subtotal,


            'ot_periods': data.ot_periods,
            'ot_rate': data.ot_rate,
            'ot_subtotal': data.ot_subtotal,

            'service_total': total  # Add the service total to the dictionary
        }

        invoice_data_list.append(data_dict)
    
    
    context = {
        'invoice_data': invoice_data_list,
        "invoice_info": invoice_info,
        'domain_url': settings.BASE_URL,
        'url': url,
        'formatted_date': formatted_date,
        'invoice_date': invoice_date,
        'st_count' : len(invoice_data_list),
        'group_name' : g.name
        
    }
    
    return render(request, 'create_bill_2.html', context)




@csrf_exempt
def upload_pdf(request):

    if request.method == 'POST' and request.FILES['pdf_file']:
        pdf_file = request.FILES['pdf_file']
        title = request.POST.get('title')
        st_count = request.POST.get('st_count')
        group_name = request.POST.get('group_name')
        
        pdf_document = PDFInvoice.objects.create(
            title=title,
            st_count=st_count,
            group_name=group_name,
            pdf_file=pdf_file
        )

        invoice= GroupByMonth.objects.get(invoice_date=title, is_downloaded=False)
        GroupByMonth.objects.filter(pk=invoice.pk).update(is_downloaded= True)
        
        print("inv", invoice)

        return JsonResponse({'message': 'Download successfully', 'document_id': pdf_document.id})
    return JsonResponse({'error': 'Invalid request'}, status=400)



@superuser_required
def update_invoice_date(request, inv_date, group_id):  
    context = {}
    context['inv_date'] =inv_date
    if request.method == "POST":
        try:
            gp_inv_date = request.POST.get('gp_inv_date')
            if GroupByMonth.objects.filter(invoice_date=gp_inv_date,group_id=group_id,is_downloaded=False).exists():
                messages.error(request, 'Invoice for selected date & group already exists, You should delete that invoice')

            else:

                invoice= GroupByMonth.objects.get(invoice_date=inv_date,group_id=group_id)
                GroupByMonth.objects.filter(pk=invoice.pk).update(invoice_date = gp_inv_date)

                queryset = invoiceDetails.objects.filter(invoice_date=inv_date,group_id=group_id)
                # print("invoice_detail", queryset)
                queryset.update(invoice_date = gp_inv_date)
            

                messages.success(request, 'Invoice date updated successfully')
                return redirect('invoice_list')
        
        except Exception as e:
            printException()
            messages.success(request, str(e))
            return render(request, 'web/update-gp-invoice-date.html', context)
    return render(request, 'web/update-gp-invoice-date.html', context)




@superuser_required
def delete_invoice_group(request, inv_date, group_id):  
    
    try:
        invoice= GroupByMonth.objects.get(invoice_date=inv_date,group_id=group_id)
        GroupByMonth.objects.filter(pk=invoice.pk).delete()

        queryset = invoiceDetails.objects.filter(invoice_date=inv_date,group_id=group_id)
        # print("invoice_detail", queryset)
        queryset.delete()

        messages.success(request, 'Invoice deleted successfully')
        return redirect('invoice_list')
    except Exception as e:
        printException()
        messages.success(request, str(e))
        return redirect('invoice_list')



def display_pdf(request, document_id):
    document = PDFInvoice.objects.get(pk=document_id)
    return render(request, 'web/display_pdf.html', {'document': document})



def delete_invoice(request, invoice_date,group_id):
    context = {}
    # service_total = []

    # Filter the invoice details based on the invoice_date
    invoice_data = invoiceDetails.objects.filter(invoice_date=invoice_date, group=group_id)

    try:
        # Get the basic info, if it exists
        invoice_info = BasicInfo.objects.get(pk=1)
        # print("Basicinfo", invoice_info)
    except BasicInfo.DoesNotExist:
        invoice_info = {}
    
    url = settings.MEDIA_ROOT
    invoice_date = datetime.strptime(invoice_date, "%Y-%m-%d")
    formatted_date = invoice_date.strftime("%B %Y")

    invoice_data_list = []

    

# def pdf(request,month,year):
#     context = {}

#     invoice_data = invoiceDetails.objects.filter(month=month, year=year)
#     try:
#         invoice_info = BasicInfo.objects.get(month=month, year=year)
#     except Exception as e:
#         printException()
#         invoice_info = {}
#     url = settings.MEDIA_ROOT
#     context = {'invoice_data': invoice_data,"invoice_info":invoice_info,'domain_url':settings.BASE_URL,'url':url}
    
#     return render(request, 'web/demo.html', context)



def sendInvoiceMail(request,month,year):
    context = {}
    try:
        from django.core.mail import EmailMessage

        # Query the invoice details based on the month and year
        invoice_data = invoiceDetails.objects.filter(month=month, year=year)
        invoice_info = BasicInfo.objects.get(month=month, year=year)
        
        # Prepare the context for rendering the HTML template
        context = {'invoice_data': invoice_data,"invoice_info":invoice_info}
        
        # Render the HTML template to a string
        html_content = render_to_string('web/invoice_pdf.html', context)
        
        # Configure pdfkit
        config = pdfkit.configuration(wkhtmltopdf='/usr/bin/wkhtmltopdf')
        
        # Generate PDF from HTML content
        pdf = pdfkit.from_string(html_content, False, configuration=config)
        print("pdf",pdf)
        
        # Create an email message
        email = EmailMessage(
            'Subject',
            'Body',
            'teambeta.clavax@gmail.com',
            ['yusufclavax@gmail.com'],
        )
        
        # Attach the PDF file
        filename = str(month) +"-" + str(year) +".pdf"
        email.attach(filename, pdf, 'application/pdf')
        
        # Send the email
        resp = email.send()
        print("resp",resp)
        if resp==1:
            context = {          
            'error': 0,
            'msg' : "Mail sent successfully"      
            } 
            
            # return HttpResponse("Email sent successfully")
        else:
            context = {          
            'error': 1,
            'msg' : "Mail not sent"      
            } 
            # return HttpResponse("Failed to send email", status=500)
    except Exception as e:
        printException()
        context = {          
            'error': 1,
            'msg' : str(e)      
            } 
        # return HttpResponse("Failed to send email", status=500)

    return JsonResponse(context)


from .utils import send_invoice_email, email_invoice

def sendMail(request, pdf_id):
    if 'userSess' not in request.session:
        return redirect('/')  
    context = {}
    
    if request.method == "POST":
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        desc = request.POST.get('desc')
        if not email:
            messages.error(request, 'Email Required')
        elif not subject:
            messages.error(request, 'Subject Required')
        elif not desc:
            messages.error(request, 'Description Required')
        # print("recemail", email)
        else: 
            try:
                documents = PDFInvoice.objects.get(pk=pdf_id)
                # send_invoice_email(email, documents, subject, desc)
                document= documents.pdf_file.path
                # print("doc",documents)
                # print("docpath",documents.pdf_file.path)
                email_invoice(email, document, subject, desc)
                
                # send_invoice_email(email, document, subject, desc)
                messages.success(request, 'Mail Sent successfully')
                PDFInvoice.objects.filter(pk=pdf_id).update(mail_status = True)
                return redirect('download_invoice_list')
            
            except Exception as e:
                # printException(str(e))
                # messages.error(request, (str(e)))
                messages.error(request, 'Something went wrong please try again later')
                return render(request, 'web/send-mail.html', context)
    return render(request, 'web/send-mail.html', context)





# def generate_pdf(request, month, year):
#     # Render HTML content from a Django template or any other source
#     url = settings.MEDIA_ROOT
#     print("url",url)
#     html_content = render_to_string('web/demo.html', {'url': url})

#     # Create a temporary file to store the PDF
#     with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
#         # Generate PDF from HTML content
#         pisa_status = pisa.CreatePDF(html_content, dest=temp_file)

#         if pisa_status.err:
#             return HttpResponse('Failed to generate PDF', status=500)

#         # Move the temporary file to the desired location
#         temp_file_path = temp_file.name
#         save_path = '/var/www/html/IEP/iep-invoice/filename.pdf'  # Specify the desired save location
#         os.rename(temp_file_path, save_path)

#     # Optionally, you can serve the generated PDF for download
#     with open(save_path, 'rb') as pdf_file:
#         response = HttpResponse(pdf_file.read(), content_type='application/pdf')
#         response['Content-Disposition'] = 'attachment; filename=filename.pdf'
#         response['xhtml2pdf.default_pdf_format'] = {
#             "format": "letter",
#             "orientation": "landscape"
#         }
#         return response





def generate_pdf(request, month, year):
    # Get the HTML template
    url = settings.MEDIA_ROOT
    invoice_data = invoiceDetails.objects.filter(month=month, year=year)
    try:
        invoice_info = BasicInfo.objects.get(month=month, year=year)
    except BasicInfo.DoesNotExist:
        invoice_info = None

    context = {
        'invoice_data': invoice_data,
        'invoice_info': invoice_info,
        'domain_url': settings.BASE_URL,
        'url':url
    }

    template = get_template('web/demo.html')
    html = template.render(context)

    # Generate PDF
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        file_name = 'printer_output_' + datetime.datetime.now().strftime('%Y-%m-%d')
        response = HttpResponse(result.getvalue(), content_type='image/svg"')
        response['Content-Disposition'] = 'attachment; filename=' + file_name + '.pdf'
        response['xhtml2pdf.base_url'] = request.build_absolute_uri('/')
        response['xhtml2pdf.default_pdf_format'] = {
            "format": "letter",
            "orientation": "landscape"
        }
        return response
    else:
        return HttpResponse('Error generating PDF: %s' % pdf.err, status=500)

# from django_xhtml2pdf.utils import pdf_decorator
# @pdf_decorator(pdfname='new_filename.pdf')
# def generate_pdf(request,month, year):
#     return render(request, 'web/demo.html')

# def generate_pdf(request, month, year):
#     # Get the HTML template
#     invoice_data = invoiceDetails.objects.filter(month=month, year=year)
#     try:
#         invoice_info = BasicInfo.objects.get(month=month, year=year)
#     except BasicInfo.DoesNotExist:
#         invoice_info = None

#     context = {
#         'invoice_data': invoice_data,
#         'invoice_info': invoice_info,
#         'domain_url': settings.BASE_URL
#     }

#     template = get_template('web/demo.html')
#     html = template.render(context)
#     result = BytesIO()
#     pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
#     if not pdf.err:
#         file_name = 'printer_output_' + datetime.datetime.now().strftime('%Y-%m-%d')
#         response = HttpResponse(result.getvalue(), content_type='application/pdf')
#         response['Content-Disposition'] = 'attachment; filename=' + file_name + '.pdf'

#     # # Create a PDF file
#     # response = HttpResponse(content_type='application/pdf')
#     # response['Content-Disposition'] = 'attachment; filename="output.pdf"'

    
#     # # Generate PDF
#     # pisa_status = pisa.CreatePDF(html, dest=response)
#     # if pisa_status.err:
#     #     return HttpResponse('Error generating PDF: %s' % pisa_status.err, status=500)
    
#     return response

import pandas as pd

def upload_excel(request):
    context = {}
    base_url = request.build_absolute_uri()
    split_url = base_url.split('/')
    context['end_point'] = split_url[3]
    try:
        if request.method == 'POST' and request.FILES:
            excel_file = request.FILES['excel_file']
            # Check if the uploaded file is of the correct type
            if excel_file.name.endswith('.xlsx'):
                df = pd.read_excel(excel_file)
                # Check if the expected columns exist in the Excel file
                expected_columns = ['name', 'email', 'mobile', 'gender']
                if all(col in df.columns for col in expected_columns):
                    for index, row in df.iterrows():
                        try:
                            # Validate and clean the data before saving it to the database
                            name = row['name'].strip()  # Remove leading and trailing spaces
                            email = row['email'].strip() if pd.notnull(row['email']) else None
                            mobile = str(row['mobile']).strip() if pd.notnull(row['mobile']) else None
                            gender = row['gender'].strip().lower()
                            if gender == "male":
                                gender = '1' 
                            elif gender == 'female':
                                gender = '2' 
                            else:
                                gender = '3'
                            User.objects.create(
                                name=name,
                                email=email,
                                mobile=mobile,
                                gender=gender
                                # Add more fields as needed
                            )
                        except Exception as e:
                            printException()
                    context['message'] = "Data Uploaded Successfully"
                else:
                    context['error'] = "The Excel file is missing one or more expected columns"
            else:
                context['error'] = "Invalid file type. Please upload a .xlsx file."
        
    except Exception as e:
        printException()
        context['error'] = str(e)
    return render(request, 'web/upload-student.html', context)