from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.db import models
from django.core.validators import RegexValidator
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.core.validators import MinValueValidator

from .managers import CustomUserManager


# class UserType(models.Model):
#     user_type = models.CharField(_('User Type'), max_length=50)
    
#     class Meta:
#         db_table = 'iep_inv_usertype'
#         app_label = 'user'

#     def __str__(self):
#         return self.user_type
    

class User(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(_("email address"), unique=True)
    name = models.CharField(_('First Name'), max_length=255, blank=False, null=False)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{4,15}$',
                                 message="Please Enter only digits between 4 to 15 characters")
    mobile = models.CharField(_('Mobile'), max_length=15, default='', null=True, blank=True, validators=[phone_regex])
    # user_type = models.ForeignKey(UserType, null=True,on_delete=models.SET_NULL)
    gender = models.CharField(
        max_length=10, blank=True,
        choices=(
            ('', 'Select Gender'),
            ('1', 'Male'),
            ('2', 'Female'),
            ('3', 'Prefer not to say')
        ),
        default=''
    )
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    date_joined = models.DateTimeField(default=timezone.now)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    class Meta:
        db_table = "user"
        verbose_name = "User"

    def __str__(self):
        return self.email
    
    
class BasicInfo(models.Model):
    from_name = models.CharField(_('From Name'), max_length=255, blank=False, null=False)
    to_name = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    from_address = models.TextField(blank=True, null=True)
    to_address = models.TextField(blank=True, null=True)
    logo = models.ImageField(upload_to="basicinfo", blank=True, null=True)
    # month = models.CharField(max_length=255, blank=False, null=False)
    month = models.PositiveIntegerField(default=1)
    year = models.PositiveIntegerField(default=2024)
    invoice_date = models.DateField(default=timezone.now)
    invoice_period_from = models.DateField(default=timezone.now)
    invoice_period_to = models.DateField(default=timezone.now)
    approved_by = models.ImageField(upload_to="basicinfo", null=True, blank=True, default='')
    prepared_by = models.ImageField(upload_to="basicinfo", null=True, blank=True, default='')
    approved_by_detail = models.TextField(blank=True, null=True)
    prepared_by_detail = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(
        _("Updated Date"), auto_now_add=False, auto_now=True)
    
    class Meta:
        db_table = "basic_info"
        verbose_name = "BasicInfo"
        unique_together = ('month', 'year',)

    def __str__(self):
        return str(self.id)
    

class invoiceDetails(models.Model):
    user = models.ForeignKey('User', on_delete=models.CASCADE, null=True, related_name="invoice_user")
    group = models.ForeignKey('Group', on_delete=models.CASCADE, null=True, related_name="group")
    invoice_date = models.DateField(_("Invoice Date"),null=True,blank=True)
    
    # day = models.PositiveIntegerField(default=1)

    month = models.PositiveIntegerField(default=1)
    year = models.PositiveIntegerField(default=2024)
    total = models.FloatField(default=0,validators=[MinValueValidator(0)])

    student_name = models.CharField(_('Student Name'), max_length=255, blank=False, null=False,default='Test Student')
    
    attendance = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    attendance_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    attendance_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    attendance_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    trt = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    trt_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    trt_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    trt_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    aide = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    aide_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    aide_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    aide_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    aid = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    aid_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    aid_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    aid_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    lang_speech = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    lang_speech_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    lang_speech_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    lang_speech_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    behavior = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    behavior_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    behavior_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    behavior_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    occupational = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    occupational_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    occupational_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    occupational_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    ic = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    ic_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    ic_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    ic_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    ca = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    ca_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    ca_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    ca_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    ot = models.CharField(_('To Name'), max_length=255, blank=False, null=False)
    ot_periods = models.FloatField(default=0,validators=[MinValueValidator(0)])
    ot_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    ot_subtotal = models.FloatField(default=0,validators=[MinValueValidator(0)])
    
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    
    class Meta:
        db_table = "invoice_details"
        verbose_name = "invoiceDetails"
        unique_together = ('month', 'year','student_name','group')

    def __str__(self):
        return str(self.id)


class Service(models.Model):
    # user = models.ForeignKey('User', on_delete=models.CASCADE, null=True, related_name="service_user")

    service_name = models.CharField(_('Services Name'), max_length=255, blank=False, null=False)
    service_rate = models.FloatField(default=0,validators=[MinValueValidator(0)])
    key_title = models.CharField(_('Key Title'), max_length=255, blank=False, null=False, default='')
    key_period = models.CharField(_('Key Periods'), max_length=255, blank=False, null=False,default='')
    key_rate = models.CharField(_('Key Rate'), max_length=255, blank=False, null=False,default='')
    key_subtotal = models.CharField(_('Key Subtotal'), max_length=255, blank=False, null=False,default='')

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    
    class Meta:
        db_table = "service"
        verbose_name = "service"

    def __str__(self):
        return str(self.id)


class Group(models.Model):
    name = models.CharField(_('Group Name'), max_length=255, blank=False, null=False)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
        
    class Meta:
        db_table = "group"
        verbose_name = "group"

    def __str__(self):
        return str(self.id)


class GroupByMonth(models.Model):
    group = models.ForeignKey('Group', on_delete=models.CASCADE, null=True, related_name="group_by_month")
    invoice_date = models.DateField(_("Invoice Date"),null=True,blank=True)
    month = models.PositiveIntegerField(default=1)
    year = models.PositiveIntegerField(default=2024)
    is_active = models.BooleanField(default=True)

    is_downloaded = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(_("Updated Date"), auto_now_add=False, auto_now=True)
        
    class Meta:
        db_table = "group_by_month"
        verbose_name = "group_by_month"

    def __str__(self):
        return str(self.id)
    



class PDFInvoice(models.Model):
    title = models.CharField(max_length=255)
    st_count = models.PositiveIntegerField(default=0)
    group_name = models.CharField(max_length=255, blank=True, null=True)
    pdf_file = models.FileField(upload_to='invoice/')
    created_at = models.DateTimeField(auto_now_add=True)
    mail_status = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Send email after saving the PDF file
        # send_invoice_email(self)
