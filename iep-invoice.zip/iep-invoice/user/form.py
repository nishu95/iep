from django import forms
from .models import invoiceDetails

class invoiceDetailsForm(forms.ModelForm):
    # Define your form fields here
    class Meta:
        model = invoiceDetails
        fields = '__all__' # Replace 'date_field' with the name of your date field
