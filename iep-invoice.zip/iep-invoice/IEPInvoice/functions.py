import os
import math

from django.db import connection, transaction
import datetime
import pytz
from decimal import Decimal
import json
import random
import string
from django.utils import timezone
import calendar
import time
import linecache
import sys

from django.conf import settings


def printException(): # this function is used for printing error on which line no and what error occured
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)
    error_str = 'EXCEPTION IN ({}, LINE {} "{}"): {}'.format(filename, lineno, line.strip(), exc_obj)
    print(error_str)
    return error_str



def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR') if request is not None else ""
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR') if request is not None else ""
    return ip


def getCurrentTimeStamp():
    return timezone.now().strftime('%d%m%Y%H%M%S%f')



def concate_file_name_with_timezone(fileName):
    fileName = str(fileName)
    fileName = fileName.replace(" ", "_")
    file_arr = fileName.split('.')[0:-1]
    file_name = ".".join(file_arr)
    file_extension = fileName.split('.')[-1]
    current_time = getCurrentTimeStamp()
    final_final_name = file_name+"_"+current_time+"."+file_extension
    return final_final_name

def handle_uploaded_file(f, path, on_upload="local"):
    
    with open(path, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)
    
    
def file_save_by_source(request, path,filename=None,on_upload="local"):
          
    try:        
        if filename != None :  
            source = filename

        fileName = concate_file_name_with_timezone(source.name)
        filePath = path
        
        if not os.path.isdir(filePath):
            os.makedirs( filePath, 493 )
        handle_uploaded_file(source, filePath + '/'+ fileName, on_upload=on_upload)
        
        return fileName

    except Exception as e:
        print(e)
        return ""


def remove_file(request,path,filename):
    try:
        filepath = path+filename

        if os.path.exists(filepath):
            os.remove(filepath)
        else:
            print("The file does not exist")

        return True

    except Exception as e:
        print(e)
        return False
            